package midtermreviewcodeforpartc;

/**
 * A class that models a User for Uno Online.
 * The user has a name and a password.
 */
public class User {
    private String name;
    private String password;

    /**
     * Constructor that initializes the user's name and password.
     * @param givenName the name of the user
     * @param givenPass the password of the user
     */
    public User(String givenName, String givenPass) {
        this.name = givenName;
        this.password = givenPass;
    }

    /**
     * Getter for the user's name.
     * @return the user's name
     */
    public String getName() {
        return name;
    }

    /**
     * Setter for the user's name.
     * @param givenName the name to set
     */
    public void setName(String givenName) {
        this.name = givenName;
    }

    /**
     * Getter for the user's password.
     * @return the user's password
     */
    public String getPassword() {
        return password;
    }

    /**
     * Setter for the user's password.
     * @param givenPass the password to set
     */
    public void setPassword(String givenPass) {
        this.password = givenPass;
    }
}
