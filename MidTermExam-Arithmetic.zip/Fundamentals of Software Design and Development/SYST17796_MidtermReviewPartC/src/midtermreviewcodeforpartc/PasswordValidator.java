package midtermreviewcodeforpartc;

/**
 * Validates a password based on specific rules:
 * - At least 8 characters
 * - Contains at least one special character
 */
public class PasswordValidator {

    /**
     * Validates the given password.
     * @param password the password to validate
     * @return true if the password meets the criteria, false otherwise
     */
    public static boolean validate(String password) {
        if (password.length() < 8) {
            return false;
        }
        int specialCharCount = 0;
        for (int i = 0; i < password.length(); i++) {
            if (!Character.isLetterOrDigit(password.charAt(i))) {
                specialCharCount++;
            }
        }
        return specialCharCount > 0;
    }
}
