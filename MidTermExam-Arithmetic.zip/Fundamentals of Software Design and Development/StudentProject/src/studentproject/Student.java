/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studentproject;

/**
 *
 * @author sivagamasrinivasan
 * @contributor Hetvi Prajapati
 */
public class Student 
{
   private String rollNo;
   private String name;
   
   public String getRollNo() 
   {
      return rollNo;
   }
   
   public void setRollNo(String rollNo) 
   {
      this.rollNo = rollNo;
   }
   
   public String getName() 
   {
      return name;
   }
   
   public void setName(String name) 
   {
      this.name = name;
   }

   // New added method
   public void hetviprajapati() 
   {
      System.out.println("Hello from Hetvi Prajapati!");
   }
}
