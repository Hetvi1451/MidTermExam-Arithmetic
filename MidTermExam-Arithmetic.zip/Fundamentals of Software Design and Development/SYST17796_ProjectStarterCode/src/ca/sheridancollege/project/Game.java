package ca.sheridancollege.project;

/**
 * The abstract Game class provides a template for any card game.
 * Our KingsInTheCornerGame class will extend this.
 */
public abstract class Game {
    private final String gameName;

    public Game(String name) {
        this.gameName = name;
    }

    public String getGameName() {
        return gameName;
    }

    /**
     * Abstract method to be implemented in KingsInTheCornerGame.java
     */
    public abstract void play();

    /**
     * Abstract method to declare the winner.
     */
    public abstract void declareWinner();
}
