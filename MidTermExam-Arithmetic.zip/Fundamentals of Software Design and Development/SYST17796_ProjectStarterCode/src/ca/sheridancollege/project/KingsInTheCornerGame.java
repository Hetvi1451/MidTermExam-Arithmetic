package ca.sheridancollege.project;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class KingsInTheCornerGame extends Game {
    private List<Player> players;
    private Deck deck;
    private List<List<Card>> foundationPiles;
    
    public KingsInTheCornerGame(String name) {
        super(name);
        players = new ArrayList<>();
        deck = new Deck();
        foundationPiles = new ArrayList<>(4);
        
        // Initialize empty foundation piles
        for (int i = 0; i < 4; i++) {
            foundationPiles.add(new ArrayList<>());
        }
    }

    public void addPlayer(String name) {
        players.add(new Player(name));
    }

    public void dealInitialCards() {
        for (Player player : players) {
            for (int i = 0; i < 7; i++) {
                player.addCardToHand(deck.drawCard());
            }
        }
    }

    public void play() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Welcome to Kings in the Corner!");
        dealInitialCards();

        boolean gameRunning = true;
        while (gameRunning) {
            for (Player player : players) {
                System.out.println("\n" + player.getName() + "'s turn.");
                System.out.println("Your hand: " + player.getHand());

                System.out.println("Enter 'draw' to pick a card, or 'play' to play a card: ");
                String action = scanner.nextLine();

                if (action.equalsIgnoreCase("draw")) {
                    Card drawnCard = deck.drawCard();
                    if (drawnCard != null) {
                        player.addCardToHand(drawnCard);
                        System.out.println(player.getName() + " drew: " + drawnCard);
                    } else {
                        System.out.println("Deck is empty! No more cards to draw.");
                    }
                } else if (action.equalsIgnoreCase("play")) {
                    System.out.println("Enter the index of the card you want to play (starting from 0): ");
                    int cardIndex = scanner.nextInt();
                    scanner.nextLine(); // Consume newline

                    if (cardIndex >= 0 && cardIndex < player.getHand().size()) {
                        Card playedCard = player.getHand().get(cardIndex);
                        player.playCard(playedCard);
                        System.out.println(player.getName() + " played: " + playedCard);
                    } else {
                        System.out.println("Invalid card index!");
                    }
                }

                if (player.hasNoCards()) {
                    System.out.println(player.getName() + " has won the game!");
                    gameRunning = false;
                    break;
                }
            }
        }
        scanner.close();
    }

    public void declareWinner() {
        for (Player player : players) {
            if (player.hasNoCards()) {
                System.out.println(player.getName() + " wins the game!");
                return;
            }
        }
    }

    public static void main(String[] args) {
        KingsInTheCornerGame game = new KingsInTheCornerGame("Kings in the Corner");
        game.addPlayer("Player 1");
        game.addPlayer("Player 2");

        game.play();
        game.declareWinner();
    }
}
